import { tour } from "./tour";
import { destination } from "./destination";
import { galleryImage } from "./galleryImage";
import { testimonial } from "./testimonial";
import { faq } from "./faq";
import { post } from "./post";

export const schema = { types: [tour, destination, galleryImage, testimonial, faq, post] };
